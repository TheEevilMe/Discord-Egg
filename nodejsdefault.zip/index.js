console.log('█▀▄ █▄█ █▀▀ ▀▄▀ █░█ █▀█ █▀ ▀█▀\n█▄▀ ░█░ ██▄ █░█ █▀█ █▄█ ▄█ ░█░\n');
console.log('Welcome to your NodeJS hosting server');
console.log('Thank you for trusting DyexHost Web Services. Thanks To(LootBox And Marq)');
console.log('>> To install your bot, connect to the server via SFTP');
console.log('                                            ');                                                                                                              

process.stdin.resume();